# dag-to-lua

This is a lib for generating [`Apache APISIX Script`](https://github.com/apache/apisix/blob/master/doc/architecture-design.md#script)